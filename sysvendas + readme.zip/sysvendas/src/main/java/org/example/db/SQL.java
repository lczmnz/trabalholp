package org.example.db;

public class SQL {

    public static final String
            //  Table
            // =======
            TABLE_TIRE    = "Pneus",

            //  Columns
            // =========
            COLUMN_NAME = "nome",
            COLUMN_ID = "id",
            COLUMN_PATH = "path",
            COLUMN_VALUE = "valor";

            public static final String URL = "jdbc:sqlite:src/main/java/org/example/db/SisVendas.db";
            public static final String USER = "";
            public static final String PASSWORD = "";
}
