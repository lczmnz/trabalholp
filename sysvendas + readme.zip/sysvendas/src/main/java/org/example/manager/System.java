package org.example.manager;

public class System {
    public static String PATH_IMAGES = "src/main/resources/";
}
