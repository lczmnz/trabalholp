package org.example.manager;
import javax.swing.*;
import java.awt.*;


public class Forms extends JFrame {


    protected JPanel workspace = new JPanel();
    protected Color BKG = new Color (0xFCFCFC);

    public static final int WIDTH = 900, HEIGHT = 600;
   public Forms (String name, Dimension size ){
       perfil(name, size);
   }
   public Forms(String name) {
       perfil(name, new Dimension (WIDTH, HEIGHT));
          }

   public void running (boolean flag){
        setVisible (flag);
    }
    private void perfil(String name, Dimension size){
       setIconImage(new ImageIcon(System.PATH_IMAGES+"pneu01.png").getImage());
       setTitle(name);
       setContentPane(workspace);
        setSize(size);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        workspace.setBackground(BKG);
        this.setLocationRelativeTo(null);
    }
}

