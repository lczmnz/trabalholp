package org.example.product;
import org.example.db.Archivable;
import org.example.db.SQL;
import org.example.manager.Forms;
import javax.swing.*;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Tires implements Archivable {
    @Override
    public void read(ResultSet result) throws SQLException {
        nome  = result.getString (  SQL.COLUMN_NAME);
        path  = result.getString (  SQL.COLUMN_PATH);
        valor  = result.getFloat (  SQL.COLUMN_VALUE);
    }
    @Override
    public String edit() {
        return "";
    }
    @Override
    public String[] write() {
        return null;
    }
    @Override
    public void clear() {
        nome  = "";
        path   = "";
        valor  = 0.00F;
    }
    String path = "";
    String nome = "";
    float valor = 0.0f;


    public void setPath(String path){
        this.path = path;
    }
    public String getPath(){
        return path;
    }

    public void setNome(String nome){
        this.nome = nome;
    }
    public String getNome(){
        return nome;
    }
    public Tires(){
    }
    public Tires (String nome){
        this.nome = nome;
    }
    public void setValor(float valor){
        this.valor = valor;
    }
    public float getValor(){
        BigDecimal price = new BigDecimal(valor);
        price.setScale(2);
        return price.floatValue();
    }
    public String getValueStr(){
        BigDecimal price = new BigDecimal(valor);
        price = price.setScale(2);
        return price.toString();
    }

    public String infovalue (){
        return getNome() + " --- Valor: R$" + getValueStr();
    }
    public Tires (String nome, float valor){
        this.nome = nome;
        this.valor = valor;
    }


}
