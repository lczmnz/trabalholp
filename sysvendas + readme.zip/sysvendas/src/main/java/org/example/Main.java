package org.example;
import org.example.pages.Cart;
import org.example.pages.Login;
import org.example.pages.Menu;
import org.example.pages.Pdv;
import org.example.product.Tires;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {
        start();
    }
    private static void start() {
        new Login().running(true);
        //new Menu().running(true);
        //new Pdv().running(true);
        //new Cart().running(true);



    }
}