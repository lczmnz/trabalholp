package org.example.pages;

import org.example.manager.Forms;
import org.example.product.Tires;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.concurrent.Flow;

public class Cart extends Forms {

    public static ArrayList<Tires> pneus = new ArrayList<>();

    public static String soma (){
        float total = 0;
        for(var pneu:pneus) total += pneu.getValor();
        BigDecimal price = new BigDecimal(total);
        price = price.setScale(2);
        return price.toString();
    }
    private JPanel head(){
        JPanel panel = new JPanel();
        panel.add(Box.createVerticalGlue());
        panel.add(new JLabel("Produtos Selecionados"));
        panel.add(Box.createVerticalGlue());
        return panel;
    }
    private void body(){
        for(var pneu: pneus){
            JPanel panel = new JPanel();
            panel.add(new Label(pneu.infovalue()));
            workspace.add(panel);
        }
    }
    private JPanel low(){
        JPanel panel = new JPanel();
        panel.add(voltar("Voltar"));
        panel.add(confirmarpgt("Confirmar Pagamento"));
        return panel;
    }

    private void inicio(){
        workspace.setLayout(new BoxLayout(workspace, BoxLayout.Y_AXIS));
        workspace.add(head());
        body();
        workspace.add(low());
    }

    private JButton confirmarpgt (String pgt){
        JButton btn = new JButton(pgt);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Pdv().running(true);
                dispose();
            }
        });
        return btn;
    }

    private JButton voltar (String vtr) {
        JButton btn = new JButton(vtr);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Menu().running(true);
                dispose();
            }
        });
    return btn;
    }

    public Cart() {
        super("Carrinho de Compras", new Dimension(500, 300));
    inicio();
    }
}
