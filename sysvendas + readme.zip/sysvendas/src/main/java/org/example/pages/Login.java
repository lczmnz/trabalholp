package org.example.pages;
import org.example.manager.Forms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Login extends Forms {

private String user = "Lucas";
private String senha = "123";
private JTextField campouser = new JTextField(15);
private JPasswordField campopassword = new JPasswordField(15);

private boolean task (){
    return (campouser.getText().equals(user) && campopassword.getText().equals(senha));
}
    private void inicio(){
        workspace.setLayout(new BoxLayout(workspace, BoxLayout.Y_AXIS));
        workspace.add(titulo());
        workspace.add(preenchimento());
        workspace.add(validacao());
    }
    private JPanel titulo(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout (panel, BoxLayout.Y_AXIS));
        panel.add(Box.createVerticalGlue());
        panel.add(new JLabel("Seja Bem-vindo à Loja!"));
        panel.add(Box.createVerticalGlue());
        panel.setBackground(BKG);
        return panel;
    }
    private JPanel preenchimento(){

        JPanel panel = new JPanel(new GridLayout(2, 1));

        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        panel1.add(new JLabel("Usuário"));
        panel1.add(campouser);
        panel2.add(new JLabel("Senha"));
        panel2.add(campopassword);
        panel.add(panel1);
        panel.add(panel2);
        panel.setBackground(BKG);
        panel1.setBackground(BKG);
        panel2.setBackground(BKG);
        return panel;
    }
    private JPanel validacao(){

        JPanel panel = new JPanel();
        panel.add(entrar("Entrar"));
        panel.setBackground(BKG);
        return panel;
    }
    private JButton entrar (String text){
        JButton btn = new JButton(text);
        btn.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!task()){
                    JOptionPane.showMessageDialog(null, "Senha e/ou usuário invalidos.");
                    return;
                }
                new Menu().running(true);
                dispose();
            }
        });
        return btn;
    }
    public Login() {
        super("Tela Login", new Dimension (275, 290));
        inicio();
    }
}