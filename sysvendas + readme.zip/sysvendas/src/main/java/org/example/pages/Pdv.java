package org.example.pages;
import org.example.manager.Forms;
import javax.swing.*;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pdv extends Forms{

    private JRadioButton radio (String nome){
        JRadioButton btn = new JRadioButton(nome);
        group.add(btn);
        return btn;
    }
    public ButtonGroup group = new ButtonGroup();


    private String
            _html = "<html> <body>",
            html_ = "</body> </html>";
    private JLabel placar = new JLabel();
    private void create_placar() {
        placar.setText("");
        String html = _html + "<table border='1'> <tr> <th> Produto </th> <th> Valor </th> </tr>";
        for (var pneu : Cart.pneus) html += "<tr> <td> "+pneu.getNome()+" </td> <td> R$ "+pneu.getValueStr()+" </td> </tr>";
        html += "<tr> <th>Total</th> <th>R$"+Cart.soma()+"</th> </tr> </table>" + _html;
        placar.setText(html);
    }

    private JPanel top(){
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        create_placar();
        panel.add(placar);
        return panel;
    }
    private JPanel body(){
        JPanel panel = new JPanel(new GridLayout(2, 2 ));
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        JPanel panel1 = new JPanel();
        panel1.add(radio ("Pix"));
        panel1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(panel1);

        JPanel panel2 = new JPanel();
        panel2.add(radio ("Crédito"));
        panel2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(panel2);

        JPanel panel3 = new JPanel();
        panel3.add(radio ("Débito"));
        panel3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(panel3);

        JPanel panel4 = new JPanel();
        panel4.add(radio ("Dinheiro"));
        panel4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(panel4);

        return panel;
    }

    private JPanel down(){
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        JPanel panel1 = new JPanel();

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        panel1.add (voltar("Voltar"));
        panel1.add(confirmarpgt("Confirmar Pagamento")) ;
        panel.add(panel1);


        return panel;
    }

    private JButton voltar (String vtr){
        JButton btn = new JButton(vtr);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Cart().running(true);
                dispose();
            }
        });
     return btn;
    }

    private JButton confirmarpgt (String pgt){
        JButton btn = new JButton(pgt);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (group.getSelection() == null){
                    JOptionPane.showMessageDialog(null, "Selecione uma forma de pagamento.");
                    return;
                }
                int opt = JOptionPane.showConfirmDialog(null, "Obrigado por realizar a compra!\n Deseja comprar mais algo? ","" ,JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, new ImageIcon("src/main/resources/pneu01.png"));
                if(opt == JOptionPane.YES_OPTION) new Menu().running(true);
                dispose();

            }
        });
        return btn;
    }


    private void inicio(){
        workspace.setLayout(new BoxLayout(workspace, BoxLayout.Y_AXIS));
        workspace.add(top());
        workspace.add(body());
        workspace.add(down());
    }

    public Pdv() {
        super ("Forma de pagamento", new Dimension(300, 400));
        inicio();
    }
}
