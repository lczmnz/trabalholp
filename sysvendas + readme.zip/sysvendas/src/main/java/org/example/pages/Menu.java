package org.example.pages;
import org.example.db.Query;
import org.example.db.SQL;
import org.example.manager.Forms;
import org.example.product.Tires;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends Forms {

    private Query bank = new Query();
    private void initdata(){
        for(int i = 1; i <= 6; i++){
            Tires pneus = new Tires();
            bank.select(SQL.TABLE_TIRE, SQL.COLUMN_ID, i+"", pneus);

            description[i-1] = pneus.getNome();
            images[i-1]= pneus.getPath();
            values[i-1]= pneus.getValor();
        }
    }
    class Markbtn extends JButton {
        public Tires tire = null;
        public boolean flag = true;
        Markbtn(String text, String image){
            super(text, new ImageIcon(image));
            setBackground(new Color(208, 208, 208));
        }
        public void setTire(Tires tire){
            this.tire = tire;
        }
        public Tires getTire(){
            return tire;
        }

    }
    private String[] description = new String[6];
    private float [] values = new float[6];
    private String[] images = new String[6];

    private Markbtn task (String text, String image, float valor){
        Markbtn btn = new Markbtn (text,image);
        btn.setVerticalTextPosition(SwingConstants.BOTTOM);
        btn.setHorizontalTextPosition(SwingConstants.CENTER);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn.flag){
                    btn.setBackground(new Color(55, 143, 255));
                    Tires pneu = new Tires(text, valor);
                    btn.setTire(pneu);
                    Cart.pneus.add(pneu);
                }
                else{
                    btn.setBackground(new Color(208,208,208));
                    Cart.pneus.remove(btn.getTire());
                }
            btn.flag = !btn.flag;
            }
        });
        return btn;
    }
    private JPanel north(){
        JPanel panel = new JPanel();
        JPanel panel1 = new JPanel();
        panel1.add(new JLabel("Selecione o(s) pneu(s) desejado(s):"));
        panel1.add(Box.createHorizontalStrut(550));
        panel1.add(carrinhodecompras("Carrinho"));
        panel.add(panel1);

        return panel;
    }
    private JPanel center() {
        JPanel panel = new JPanel(new GridLayout(2, 3));
        for (int i = 0 ; i<6 ; i++)
            panel.add((task(description[i],images[i], values[i])));
        return panel;
    }

    private JButton carrinhodecompras (String cart){
        JButton btn = new JButton(cart, new ImageIcon("src/main/resources/carrinho.png"));
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Cart().running(true);
                dispose();
            }
        });
        return btn;
    }

    private void inicio(){
        workspace.setLayout(new BorderLayout());
        workspace.add(north(), BorderLayout.NORTH);
        workspace.add(center(), BorderLayout.CENTER);
    }
    public Menu() {
        super("Menu");
        Cart.pneus.clear();
        initdata();
        inicio();
    }

}
